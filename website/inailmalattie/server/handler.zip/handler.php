<?php
	header('Content-Type: text/json');
	require_once("config.php");
	$action = $_POST['action'];
	
	switch($action) {
		case "load" :
			loadData();
		break;
		case "filter" :
			filterData();
		break; 	
	}

	
	function loadData() {
		try{
		//$query = 'SELECT singolesedi.latitudineProvincia, singolesedi.longitudineProvincia FROM datisemestrali JOIN singolesedi on datisemestrali.sedeInail=singolesedi.codice'; 
			$query = 'SELECT singolesedi.latitudineProvincia, singolesedi.longitudineProvincia, count(*) AS count FROM datisemestrali JOIN singolesedi on datisemestrali.sedeInail=singolesedi.codice group by singolesedi.latitudineProvincia, singolesedi.longitudineProvincia';
			$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE); 
			$result = $mysqli->query($query); 
			$data = array();	
			
			while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
				
				$latitudine = $row['latitudineProvincia'];
				$longitudine = $row['longitudineProvincia'];
				$count = $row['count'];
				$dataElement = array("latitudine" => $latitudine,"longitudine" =>$longitudine, "count" => $count);
				array_push($data, $dataElement);
			}
			
			//fwrite($myfile, json_encode($response));
			//fclose();
			$JSON = json_encode($data);
			echo $JSON;
		}
		catch (Exception $e) {
			$myfile = fopen("logs.txt", "w") or die("Unable to open file!");
			fwrite($myfile, $e->getMessage());
			fclose();
		}
	
	}
	function filterData(){
		try{
			$myfile = fopen("logs.txt", "w") or die("Unable to open file!");
			
			$tumore=$_POST['tumore']; //tumore può essere 1 (se il filtro è attivo) oppure 0
			$amianto=$_POST['amianto']; //amianto può essere 1 (se il filtro è attivo) oppure 0
			$dataInizio=$_POST['dataInizio'];//una data oppure 0
			$dataFine=$_POST['dataFine'];//una data oppure 0
			$morto=$_POST['morto']; //morto può essere 1 (se il filtro è attivo) oppure zero
			
			$query00 = "CREATE OR REPLACE VIEW icd10info AS SELECT singolesedi.latitudineProvincia, singolesedi.longitudineProvincia,
			settore,datisemestrali.ICD10denunciato, count(*) AS count, SUM(datisemestrali.sesso) as numeroMaschi 
			FROM datisemestrali JOIN singolesedi on datisemestrali.sedeInail=singolesedi.codice ".
			( $tumore==1 ? "JOIN tumori on datisemestrali.ICD10denunciato=tumori.id" : "" ) ."
			WHERE ". (($morto==1) ? " datisemestrali.dataMorte is not NULL" : "datisemestrali.dataMorte is not NULL or datisemestrali.dataMorte is NULL") ."
			".($amianto==1 ? "AND datisemestrali.asbestoCorrelata=1" : "") ."
			". ($dataInizio!=0 ? "AND datisemestrali.data>'".$dataInizio."' AND datisemestrali.data<'".$dataFine."'" : "" )." GROUP BY singolesedi.latitudineProvincia, singolesedi.longitudineProvincia,settore,ICD10denunciato;";
			
			$query01="CREATE OR REPLACE VIEW icd10max AS SELECT latitudineProvincia, longitudineProvincia, settore,MAX(count) as max, SUM(numeroMaschi) as numMaschi, SUM(count) as countTotale
			FROM icd10info
			GROUP BY latitudineProvincia, longitudineProvincia, settore;";
			//fwrite($myfile, $query);
			$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE); 
			$resultinutile00 = $mysqli->query($query00);
			$resultinutile01 = $mysqli->query($query01);
			fwrite($myfile, $mysqli->error);

			$queryuno = "SELECT icd10max.latitudineProvincia, icd10max.longitudineProvincia, icd10max.settore, ICD10denunciato, max,numMaschi,countTotale, descrizione FROM icd10max JOIN icd10info on icd10max.latitudineProvincia=icd10info.latitudineProvincia and icd10max.longitudineProvincia=icd10info.longitudineProvincia and icd10max.settore=icd10info.settore 
						JOIN codici on icd10info.ICD10denunciato=codici.id
						WHERE max=count 
						GROUP BY icd10max.latitudineProvincia, icd10max.longitudineProvincia, icd10max.settore,max;";
			
			//fwrite($myfile, $queryuno);
			
			
			$result = $mysqli->query($queryuno); 
			$data = array();
			
			while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
				$latitudine = $row['latitudineProvincia'];
				$longitudine = $row['longitudineProvincia'];
				$count = $row['countTotale'];
				$settore = $row['settore'];
				$numeroMaschi = $row['numMaschi'];
				$descrizioneMalattiaPiuDiffusa=$row['descrizione'];
				$numeroPersoneConMalattiaPiuDiffusa=$row['max'];
				$dataElement = array("latitudine" => $latitudine,"longitudine" =>$longitudine,"settore" => $settore, "count" => $count, "countMaschi" => $numeroMaschi, "numeroPersoneConMalattiaPiuDiffusa" => $numeroPersoneConMalattiaPiuDiffusa, "descrizioneMalattiaPiuDiffusa" => $descrizioneMalattiaPiuDiffusa);
				array_push($data, $dataElement);
			}
		
			$response = array("data" => $data, "type" => "load");
			echo json_encode($response);	
		}
		catch(Exception $e){
			$myfile = fopen("logs.txt", "w") or die("Unable to open file!");
			fwrite($myfile, $e->getMessage());
			fclose();
		}
	}
	/* vecchia query
	function filterData(){
		try{
			$myfile = fopen("logs.txt", "w") or die("Unable to open file!");
			$tumore=$_POST['tumore']; //tumore può essere 1 (se il filtro è attivo) oppure 0
			$amianto=$_POST['amianto']; //amianto può essere 1 (se il filtro è attivo) oppure 0
			$dataInizio=$_POST['dataInizio'];//una data oppure 0
			$dataFine=$_POST['dataFine'];//una data oppure 0
			$morto=$_POST['morto']; //morto può essere 1 (se il filtro è attivo) oppure zero
			
			$query = "SELECT singolesedi.latitudineProvincia, singolesedi.longitudineProvincia,settore, count(*) AS count, SUM(datisemestrali.sesso) as numeroMaschi 
			FROM datisemestrali JOIN singolesedi on datisemestrali.sedeInail=singolesedi.codice ".
			( $tumore==1 ? "JOIN tumori on datisemestrali.ICD10denunciato=tumori.id" : "" ) ."
			WHERE ". (($morto==1) ? " datisemestrali.dataMorte is not NULL" : "datisemestrali.dataMorte is not NULL or datisemestrali.dataMorte is NULL") ."
			".($amianto==1 ? "AND datisemestrali.asbestoCorrelata=1" : "") ."
			". ($dataInizio!=0 ? "AND datisemestrali.data>'".$dataInizio."' AND datisemestrali.data<'".$dataFine."'" : "" )." GROUP BY singolesedi.latitudineProvincia, singolesedi.longitudineProvincia,settore";
			fwrite($myfile, $query);
	
			$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE); 
			$result = $mysqli->query($query); 
			$data = array();	
			while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
				$latitudine = $row['latitudineProvincia'];
				$longitudine = $row['longitudineProvincia'];
				$count = $row['count'];
				$settore = $row['settore'];
				$numeroMaschi = $row['numeroMaschi'];
				$dataElement = array("latitudine" => $latitudine,"longitudine" =>$longitudine,"settore" => $settore, "count" => $count, "countMaschi" => $numeroMaschi);
				array_push($data, $dataElement);
			}
		
			$response = array("data" => $data, "type" => "load");
			echo json_encode($response);	
		}
		catch(Exception $e){
			$myfile = fopen("logs.txt", "w") or die("Unable to open file!");
			fwrite($myfile, $e->getMessage());
			fclose();
		}
	}*/
	
?>